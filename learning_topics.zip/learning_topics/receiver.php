<?php
  require('vendor/autoload.php');
  use PhpAmqpLib\Connection\AMQPStreamConnection;
  use PhpAmqpLib\Connection\AMQPSSLConnection;
  use PhpAmqpLib\Message\AMQPMessage;

  $connection = new AMQPStreamConnection('192.168.2.121', 5672, 'admin', '12345', '/');
  $channel = $connection->channel();

  $callback = function ($msg) {
    echo ' [x] Received ', $msg->body, "\n";
  };

  $channel->basic_consume('test_queue', '', false, true, false, false, $callback);

  while ($channel->is_consuming()) {
    $channel->wait();
  }

  $channel->close();
  $connection->close();
?>