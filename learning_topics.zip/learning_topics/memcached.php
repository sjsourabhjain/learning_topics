<?php //phpinfo();?>
<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
try

{
    $memcached = new Memcached();
    $memcached->addServer("127.0.0.1", 11211); 
    $response = $memcached->get("sample_key");
 
    if($response==true) 
    {
      echo $response;
    } 

    else

    {
    echo "Cache is empty";
    $memcached->set("sample_key", "Sample data from cache") ;
    }
}
catch (exception $e)
{
echo $e->getMessage();
}
?>