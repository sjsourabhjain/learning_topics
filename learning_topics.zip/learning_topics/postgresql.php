<?php
//phpinfo();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
    $db_connection = pg_connect("host=localhost port = 5432 dbname=testdb user=postgres password=Arka@123");
    pg_query($db_connection,"INSERT INTO COMPANY (ID,NAME,AGE,ADDRESS,SALARY)
      VALUES (3, 'Virendra', 72, 'California', 2000000.00 )");
    $result = pg_query($db_connection, "SELECT * FROM company");
    while($res = pg_fetch_array($result))
    {        
    print_r($res);
    }
?>