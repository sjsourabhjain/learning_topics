<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
  require('vendor/autoload.php');
  use PhpAmqpLib\Connection\AMQPStreamConnection;
  use PhpAmqpLib\Connection\AMQPSSLConnection;
  use PhpAmqpLib\Message\AMQPMessage;
  $connection = new AMQPStreamConnection('192.168.2.121', 5672, 'admin', '12345', '/');

  $channel = $connection->channel();

  $channel->exchange_declare('test_exchange', 'direct', false, false, false);
  $channel->queue_declare('test_queue', false, false, false, false);
  $channel->queue_bind('test_queue', 'test_exchange', 'test_key');

  $msg = new AMQPMessage('Hello World!');
  $channel->basic_publish($msg, 'test_exchange', 'test_key');

  echo " [x] Sent 'Hello World!' to test_exchange / test_queue.\n";

  $channel->close();
  $connection->close();
?>