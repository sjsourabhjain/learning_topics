<?php
//phpinfo();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$redis = new Redis();
$redis->connect('127.0.0.1', 6379);
//$redis->auth('REDIS_PASSWORD');
//-----/etc/redis/redis.conf change password 
$key = "Users";

//if the key doesn't exist in the redis cache 
if (!$redis->get($key)) {
    $source = 'MySQL Server';
    $con = mysqli_connect('localhost','root','Arka@123','btroo');
    $sql = mysqli_query($con, "SELECT * from users");
    while ($row = mysqli_fetch_array($sql)) {
       $users[] = $row;
    }
    //here is the set data in redis and assign in the key
    $redis->set($key, serialize($users));
    //set the expiry time of the redis cache 
    $redis->expire($key, 10);
} else {
     $source = 'Redis Server';
     $users = unserialize($redis->get($key));
}

echo $source . ': <br>';
print_r($users);